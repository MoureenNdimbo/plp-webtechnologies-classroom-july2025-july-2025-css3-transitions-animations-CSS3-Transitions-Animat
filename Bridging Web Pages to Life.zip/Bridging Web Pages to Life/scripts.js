// Part 1: Trigger CSS Animation
const box = document.getElementById("box");
document.getElementById("animateBtn").addEventListener("click", () => {
    box.classList.toggle("animate");
});

// Part 2: JS Functions Example (Scope, Parameters, Return)
function calculateSum(a, b) {
    return a + b;
}

let result = calculateSum(5, 10);
document.getElementById("functionResult").textContent = result;

// Part 3: Card Flip using JS + CSS
const card = document.querySelector(".card");
document.getElementById("flipBtn").addEventListener("click", () => {
    card.classList.toggle("flipped");
});